from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('home/', views.home, name='home'),
    path('add_donor/', views.add_donor, name='add_donor'),
    path('donor_list/', views.donor_list, name='donor_list'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
]
