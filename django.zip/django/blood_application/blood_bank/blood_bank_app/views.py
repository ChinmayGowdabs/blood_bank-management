# blood_bank_app/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .models import Donor  # Import the Donor model

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'blood_bank_app/login.html', {'error': 'Invalid credentials'})
    return render(request, 'blood_bank_app/login.html')

def home(request):
    donors = Donor.objects.all()
    return render(request, 'blood_bank_app/home.html', {'donors': donors})

def add_donor(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        blood_type = request.POST.get('blood_type')
        contact = request.POST.get('contact')
        
        # Validate form data here if needed
        
        # Create and save the new donor
        Donor.objects.create(name=name, blood_type=blood_type, contact=contact)
        
        # Redirect to the donor list page after saving
        return redirect('donor_list')
    
    # Render the form for GET request
    return render(request, 'blood_bank_app/add_donor.html')

def donor_list(request):
    donors = Donor.objects.all()
    return render(request, 'blood_bank_app/donor_list.html', {'donors': donors})
